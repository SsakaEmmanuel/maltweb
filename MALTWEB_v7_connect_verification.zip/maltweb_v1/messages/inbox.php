
<?php
session_start(); require_once __DIR__.'/../config/database.php';
if(!isset($_SESSION['user'])){header('Location: ../auth/login.php');exit;}
$db=getDB();$uid=(int)$_SESSION['user']['id'];
$st=$db->prepare("SELECT m.*,u.full_name sender_name,l.name listing_name FROM messages m JOIN users u ON u.id=m.sender_id LEFT JOIN listings l ON l.id=m.listing_id WHERE m.receiver_id=? ORDER BY m.id DESC");
$st->execute([$uid]);$messages=$st->fetchAll(PDO::FETCH_ASSOC);
$db->prepare("UPDATE messages SET is_read=1 WHERE receiver_id=?")->execute([$uid]);
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Messages • MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><main class="container" style="padding:40px 20px"><a href="../dashboard.php">← Dashboard</a><div class="section-heading"><div><span class="eyebrow">CONNECT</span><h1>Messages</h1><p>Conversations from people interested in your profiles.</p></div></div>
<div class="message-list"><?php foreach($messages as $m):?><article class="card message-card"><div class="message-meta"><strong><?=htmlspecialchars($m['sender_name'])?></strong><span><?=htmlspecialchars($m['created_at'])?></span></div><h2><?=htmlspecialchars($m['subject']?:'MALTWEB message')?></h2><p><?=nl2br(htmlspecialchars($m['body']))?></p><?php if($m['listing_name']):?><small>About: <?=htmlspecialchars($m['listing_name'])?></small><?php endif;?></article><?php endforeach;?></div>
<?php if(!$messages):?><div class="empty-state"><h2>No messages yet</h2><p>Your MALTWEB conversations will appear here.</p></div><?php endif;?></main></body></html>
