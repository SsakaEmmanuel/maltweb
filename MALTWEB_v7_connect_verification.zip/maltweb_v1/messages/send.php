
<?php
session_start(); require_once __DIR__.'/../config/database.php';
if(!isset($_SESSION['user'])){header('Location: ../auth/login.php');exit;}
$db=getDB();$listingId=(int)($_GET['listing_id']??0);
$st=$db->prepare("SELECT l.*,u.id owner_id,u.full_name owner_name FROM listings l JOIN users u ON u.id=l.owner_id WHERE l.id=?");
$st->execute([$listingId]);$listing=$st->fetch(PDO::FETCH_ASSOC);
if(!$listing || (int)$listing['owner_id']===(int)$_SESSION['user']['id']){header('Location: ../search.php');exit;}
$error='';$sent=false;
if($_SERVER['REQUEST_METHOD']==='POST'){
 $subject=trim($_POST['subject']??'');$body=trim($_POST['body']??'');
 if($body==='')$error='Please write a message.';
 else{
  $st=$db->prepare("INSERT INTO messages(sender_id,receiver_id,listing_id,subject,body) VALUES(?,?,?,?,?)");
  $st->execute([$_SESSION['user']['id'],$listing['owner_id'],$listingId,$subject,$body]);
  $db->prepare("INSERT INTO notifications(user_id,title,body,link) VALUES(?,?,?,?)")
     ->execute([$listing['owner_id'],'New MALTWEB message','Someone contacted you about '.$listing['name'],'../messages/inbox.php']);
  $sent=true;
 }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Contact • MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><main class="container" style="padding:40px 20px"><div class="card form-card"><a href="../listing/view.php?slug=<?=urlencode($listing['slug'])?>">← Back to profile</a><h1>Contact <?=htmlspecialchars($listing['name'])?></h1>
<?php if($error):?><div class="notice error"><?=htmlspecialchars($error)?></div><?php endif;?><?php if($sent):?><div class="notice success">Message sent successfully.</div><a class="btn" href="inbox.php">Open messages</a><?php else:?>
<form method="post"><label>Subject<input name="subject" value="Inquiry about <?=htmlspecialchars($listing['name'])?>"></label><label>Message<textarea name="body" rows="8" required placeholder="Write your message..."></textarea></label><button class="btn">Send message</button></form>
<?php endif;?></div></main></body></html>
