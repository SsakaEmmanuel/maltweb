
<?php
session_start(); require_once __DIR__ . '/../config/database.php';
if(!isset($_SESSION['user'])){header('Location: ../auth/login.php');exit;}
$db=getDB();$error='';$success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $title=trim($_POST['title']??'');$desc=trim($_POST['description']??'');$type=trim($_POST['opportunity_type']??'Opportunity');
 $org=trim($_POST['organization']??'');$loc=trim($_POST['location']??'');$deadline=trim($_POST['deadline']??'');
 $phone=trim($_POST['contact_phone']??'');$email=trim($_POST['contact_email']??'');$website=trim($_POST['website']??'');
 if($title===''||$desc==='')$error='Title and description are required.';
 else{$st=$db->prepare("INSERT INTO opportunities(owner_id,title,opportunity_type,description,organization,location,deadline,contact_phone,contact_email,website,status) VALUES(?,?,?,?,?,?,?,?,?,?,'pending')");
 $st->execute([$_SESSION['user']['id'],$title,$type,$desc,$org,$loc,$deadline,$phone,$email,$website]);$success='Opportunity submitted. It will appear publicly after admin approval.';}
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Create Opportunity • MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><main class="container" style="padding:40px 20px"><div class="card form-card"><a href="../dashboard.php">← Dashboard</a><h1>Post an opportunity</h1>
<?php if($error):?><div class="notice error"><?=htmlspecialchars($error)?></div><?php endif;?><?php if($success):?><div class="notice success"><?=htmlspecialchars($success)?></div><?php endif;?>
<form method="post"><label>Title<input name="title" required></label><label>Type<select name="opportunity_type"><?php foreach(['Job','Scholarship','Training','Internship','Tender','Volunteer','Funding','Other'] as $x):?><option><?=$x?></option><?php endforeach;?></select></label><label>Organization / company<input name="organization"></label><label>Description<textarea name="description" rows="7" required></textarea></label><label>Location<input name="location"></label><label>Deadline<input type="date" name="deadline"></label><label>Contact phone<input name="contact_phone"></label><label>Contact email<input type="email" name="contact_email"></label><label>Website<input name="website" placeholder="https://..."></label><button class="btn" type="submit">Submit opportunity</button></form>
</div></main></body></html>
