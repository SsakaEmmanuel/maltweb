<?php
require_once __DIR__ . '/../config/database.php';
if (empty($_SESSION['user_id'])) { header('Location: ../auth/login.php'); exit; }

$categories = db()->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $type = $_POST['listing_type'] ?? 'business';
    $category = (int)($_POST['category_id'] ?? 0);
    $description = trim($_POST['description'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $website = trim($_POST['website'] ?? '');

    $allowed = ['business','organization','service','project','opportunity'];
    if (!in_array($type, $allowed, true)) $type = 'business';

    if ($name === '' || $category < 1 || $location === '') {
        $message = 'Name, category and location are required.';
    } else {
        $slug = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $name), '-')) . '-' . time();
        $stmt = db()->prepare(
            'INSERT INTO listings(owner_id,category_id,name,slug,listing_type,description,phone,email,location,address,website)
             VALUES(?,?,?,?,?,?,?,?,?,?,?)'
        );
        $stmt->execute([
            $_SESSION['user_id'],$category,$name,$slug,$type,$description,
            $phone,$email,$location,$address,$website
        ]);
        header('Location: view.php?slug=' . urlencode($slug)); exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Create profile — MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css">
</head><body>
<header class="site-header"><a class="brand" href="../index.php"><span class="brand-mark">M</span><span>MALT<span>WEB</span></span></a><nav class="desktop-nav"><a href="../index.php">Explore</a><a href="../dashboard.php">Dashboard</a></nav></header>
<main class="auth-page profile-create">
<div class="auth-card wide-card">
<span class="kicker">GET DISCOVERED</span><h1>Create a MALTWEB profile</h1>
<p class="muted">Add something useful to your area: a business, organization, service, project or opportunity.</p>
<?php if($message): ?><div class="alert"><?=$message?></div><?php endif; ?>
<form method="post">
<label>Name<input name="name" required placeholder="e.g. Emmanuel Graphics"></label>
<label>Profile type<select name="listing_type"><option value="business">Business</option><option value="organization">Organization</option><option value="service">Service</option><option value="project">Project</option><option value="opportunity">Opportunity</option></select></label>
<label>Category<select name="category_id" required><option value="">Choose category</option><?php foreach($categories as $c): ?><option value="<?=$c['id']?>"><?=htmlspecialchars($c['name'])?></option><?php endforeach; ?></select></label>
<label>Location / Area<input name="location" required placeholder="e.g. Kasana, Luweero"></label>
<label>Address <small>(optional)</small><input name="address" placeholder="Street, building or landmark"></label>
<label>Description<textarea name="description" rows="5" placeholder="Tell people what this profile offers..."></textarea></label>
<div class="form-two"><label>Phone<input name="phone"></label><label>Email<input type="email" name="email"></label></div>
<label>Website <small>(optional)</small><input name="website" placeholder="https://example.com"></label>
<button class="button dark-button">Publish profile</button>
</form>
</div></main></body></html>
