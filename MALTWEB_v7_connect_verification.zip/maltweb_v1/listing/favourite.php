
<?php
session_start(); require_once __DIR__.'/../config/database.php';
if(!isset($_SESSION['user'])){header('Location: ../auth/login.php');exit;}
$id=(int)($_GET['id']??0);$back=$_SERVER['HTTP_REFERER']??'../search.php';$db=getDB();$uid=(int)$_SESSION['user']['id'];
$st=$db->prepare("SELECT 1 FROM favourites WHERE user_id=? AND listing_id=?");$st->execute([$uid,$id]);
if($st->fetchColumn()){$db->prepare("DELETE FROM favourites WHERE user_id=? AND listing_id=?")->execute([$uid,$id]);}
else{$db->prepare("INSERT OR IGNORE INTO favourites(user_id,listing_id) VALUES(?,?)")->execute([$uid,$id]);}
header('Location: '.$back);exit;
