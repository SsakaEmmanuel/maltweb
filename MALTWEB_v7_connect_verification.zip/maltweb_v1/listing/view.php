<?php
require_once __DIR__ . '/../config/database.php';
$slug = trim($_GET['slug'] ?? '');
$stmt = db()->prepare("SELECT l.*,c.name AS category_name,c.icon,u.full_name AS owner_name
                       FROM listings l
                       LEFT JOIN categories c ON c.id=l.category_id
                       LEFT JOIN users u ON u.id=l.owner_id
                       WHERE l.slug=? AND l.status='active' LIMIT 1");
$stmt->execute([$slug]);
$item = $stmt->fetch();
if (!$item) { http_response_code(404); die('Profile not found.'); }
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=htmlspecialchars($item['name'])?> — MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css">
</head><body>
<header class="site-header"><a class="brand" href="../index.php"><span class="brand-mark">M</span><span>MALT<span>WEB</span></span></a><nav class="desktop-nav"><a href="../search.php">Explore</a><a href="../auth/login.php">Login</a></nav></header>
<main class="profile-page">
<section class="profile-hero">
<div class="profile-symbol"><?=htmlspecialchars($item['icon'] ?: 'M')?></div>
<div><span class="kicker"><?=htmlspecialchars($item['category_name'] ?: 'MALTWEB PROFILE')?></span><h1><?=htmlspecialchars($item['name'])?></h1><p class="profile-location">📍 <?=htmlspecialchars($item['location'])?></p></div>
<?php if($item['verified']): ?><span class="verified">✓ Verified</span><?php endif; ?>
</section>
<section class="profile-body">
<div class="profile-main"><h2>About</h2><p><?=nl2br(htmlspecialchars($item['description'] ?: 'This profile has not added a description yet.'))?></p></div>
<aside class="contact-card"><h3>Connect</h3>
<?php if($item['phone']): ?><a href="tel:<?=htmlspecialchars($item['phone'])?>">📞 <?=htmlspecialchars($item['phone'])?></a><?php endif; ?>
<?php if($item['email']): ?><a href="mailto:<?=htmlspecialchars($item['email'])?>">✉️ <?=htmlspecialchars($item['email'])?></a><?php endif; ?>
<?php if($item['website']): ?><a href="<?=htmlspecialchars($item['website'])?>" target="_blank" rel="noopener">🌐 Website</a><?php endif; ?>
<?php if(!$item['phone'] && !$item['email'] && !$item['website']): ?><p class="muted">No contact details provided yet.</p><?php endif; ?>
</aside>
</section>
<?php if(isset($_SESSION['user'])):
$fv=$db->prepare("SELECT 1 FROM favourites WHERE user_id=? AND listing_id=?");$fv->execute([$_SESSION['user']['id'],$listing['id']]);$isFav=(bool)$fv->fetchColumn(); ?>
<div class="profile-actions"><a class="btn" href="favourite.php?id=<?=$listing['id']?>"><?=$isFav?'★ Saved':'☆ Save to favourites'?></a></div>
<?php else: ?><p class="muted">Login to save this profile to your favourites.</p><?php endif; ?><?php if(isset($_SESSION['user']) && (int)$_SESSION['user']['id'] !== (int)$listing['owner_id']): ?>
<div class="profile-actions"><a class="btn" href="../messages/send.php?listing_id=<?=$listing['id']?>">Contact this profile</a></div>
<?php endif; ?></main></body></html>
