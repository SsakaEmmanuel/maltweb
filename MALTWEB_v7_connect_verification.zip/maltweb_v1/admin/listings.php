<?php
require_once __DIR__ . '/guard.php';
$pdo=db(); $notice='';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $id=(int)($_POST['id']??0); $action=$_POST['action']??'';
    if($action==='approve') $pdo->prepare("UPDATE listings SET status='active' WHERE id=?")->execute([$id]);
    if($action==='hide') $pdo->prepare("UPDATE listings SET status='hidden' WHERE id=?")->execute([$id]);
    if($action==='verify') $pdo->prepare("UPDATE listings SET verified=1,status='active' WHERE id=?")->execute([$id]);
    if($action==='unverify') $pdo->prepare("UPDATE listings SET verified=0 WHERE id=?")->execute([$id]);
    if($action==='delete') $pdo->prepare("DELETE FROM listings WHERE id=?")->execute([$id]);
    $notice='Action completed.';
}
$rows=$pdo->query("SELECT l.*,c.name category_name,u.full_name owner_name FROM listings l LEFT JOIN categories c ON c.id=l.category_id LEFT JOIN users u ON u.id=l.owner_id ORDER BY CASE WHEN l.status='pending' THEN 0 ELSE 1 END,l.id DESC")->fetchAll();
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Listings — MALTWEB Admin</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><header class="admin-header"><a class="brand" href="../index.php"><span class="brand-mark">M</span><span>MALT<span>WEB</span></span></a><a href="index.php">← Admin dashboard</a></header>
<main class="admin-wrap"><span class="kicker">MODERATION</span><h1>Listings & approvals</h1><?php if($notice): ?><div class="success"><?=$notice?></div><?php endif; ?>
<div class="admin-table"><?php foreach($rows as $r): ?><div class="table-row"><div><strong><?=htmlspecialchars($r['name'])?></strong><small><?=htmlspecialchars($r['category_name']?:'')?> · <?=htmlspecialchars($r['listing_type'])?> · <?=htmlspecialchars($r['location']?:'')?></small><small>Owner: <?=htmlspecialchars($r['owner_name']?:'Unknown')?></small></div><div class="row-actions"><span class="status <?=htmlspecialchars($r['status'])?>"><?=htmlspecialchars($r['status'])?></span><?php if(!$r['verified']): ?><form method="post"><input type="hidden" name="id" value="<?=$r['id']?>"><button name="action" value="verify">✓ Verify</button></form><?php else: ?><form method="post"><input type="hidden" name="id" value="<?=$r['id']?>"><button name="action" value="unverify">Unverify</button></form><?php endif; ?><?php if($r['status']!=='active'): ?><form method="post"><input type="hidden" name="id" value="<?=$r['id']?>"><button name="action" value="approve">Approve</button></form><?php else: ?><form method="post"><input type="hidden" name="id" value="<?=$r['id']?>"><button name="action" value="hide">Hide</button></form><?php endif; ?><form method="post" onsubmit="return confirm('Delete this listing?')"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="danger" name="action" value="delete">Delete</button></form></div></div><?php endforeach; if(!$rows): ?><p class="muted">No listings available.</p><?php endif; ?></div></main></body></html>
