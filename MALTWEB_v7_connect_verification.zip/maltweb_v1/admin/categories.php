<?php
require_once __DIR__ . '/guard.php';
$pdo=db(); $notice='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $name=trim($_POST['name']??''); $desc=trim($_POST['description']??''); $icon=trim($_POST['icon']??'•');
    if($name){$slug=strtolower(trim(preg_replace('/[^a-z0-9]+/i','-',$name),'-')); try{$pdo->prepare("INSERT INTO categories(name,slug,description,icon) VALUES(?,?,?,?)")->execute([$name,$slug,$desc,$icon]);$notice='Category added.';}catch(Exception $e){$notice='Category already exists.';}}
}
$cats=$pdo->query("SELECT c.*,COUNT(l.id) listing_count FROM categories c LEFT JOIN listings l ON l.category_id=c.id GROUP BY c.id ORDER BY c.name")->fetchAll();
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Categories — MALTWEB Admin</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><header class="admin-header"><a class="brand" href="../index.php"><span class="brand-mark">M</span><span>MALT<span>WEB</span></span></a><a href="index.php">← Admin dashboard</a></header>
<main class="admin-wrap"><span class="kicker">STRUCTURE</span><h1>Categories</h1><div class="admin-panel category-add"><h2>Add category</h2><form method="post" class="category-form"><input name="icon" placeholder="Icon" maxlength="4"><input name="name" placeholder="Category name" required><input name="description" placeholder="Short description"><button class="button dark-button">Add</button></form></div><div class="admin-table"><?php foreach($cats as $c): ?><div class="table-row"><div><strong><?=htmlspecialchars($c['icon'])?> <?=htmlspecialchars($c['name'])?></strong><small><?=htmlspecialchars($c['description'])?></small></div><span class="role-pill"><?=$c['listing_count']?> listings</span></div><?php endforeach; ?></div></main></body></html>
