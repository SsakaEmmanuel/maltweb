
<?php
session_start(); require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/guard.php';
$id=(int)($_GET['id']??0);$action=$_GET['action']??'';
$db=getDB();
if($id>0 && in_array($action,['verify','unverify'],true)){
 $value=$action==='verify'?1:0;
 $db->prepare("UPDATE listings SET verified=? WHERE id=?")->execute([$value,$id]);
 $st=$db->prepare("SELECT owner_id,name FROM listings WHERE id=?");$st->execute([$id]);$l=$st->fetch(PDO::FETCH_ASSOC);
 if($l){$db->prepare("INSERT INTO notifications(user_id,title,body,link) VALUES(?,?,?,?)")->execute([$l['owner_id'],$value?'Profile verified':'Verification removed',$value?'Your MALTWEB profile has been verified.':'Verification on your MALTWEB profile was removed.','../listing/view.php?id='.$id]);}
}
header('Location: listings.php');exit;
?>
