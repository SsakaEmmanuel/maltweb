<?php
require_once __DIR__ . '/guard.php';

$pdo = db();
$stats = [
 'users' => (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
 'listings' => (int)$pdo->query("SELECT COUNT(*) FROM listings")->fetchColumn(),
 'pending' => (int)$pdo->query("SELECT COUNT(*) FROM listings WHERE status='pending'")->fetchColumn(),
 'verified' => (int)$pdo->query("SELECT COUNT(*) FROM listings WHERE verified=1")->fetchColumn(),
];
$recentUsers = $pdo->query("SELECT id,full_name,email,role,created_at FROM users ORDER BY id DESC LIMIT 8")->fetchAll();
$recentListings = $pdo->query("SELECT l.id,l.name,l.listing_type,l.location,l.status,l.verified,l.created_at,c.name category_name FROM listings l LEFT JOIN categories c ON c.id=l.category_id ORDER BY l.id DESC LIMIT 8")->fetchAll();
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin — MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body class="admin-body">
<header class="admin-header"><a class="brand" href="../index.php"><span class="brand-mark">M</span><span>MALT<span>WEB</span></span></a><div><span class="admin-badge">ADMIN CONTROL</span><a href="../logout.php">Logout</a></div></header>
<main class="admin-wrap">
<div class="admin-title"><div><span class="kicker">CONTROL CENTER</span><h1>MALTWEB Admin</h1><p>Manage people, profiles and the information that appears across MALTWEB.</p></div><a class="button dark-button" href="../index.php">View site</a></div>

<div class="admin-stats">
<div><span>USERS</span><strong><?=$stats['users']?></strong></div>
<div><span>LISTINGS</span><strong><?=$stats['listings']?></strong></div>
<div class="attention"><span>PENDING</span><strong><?=$stats['pending']?></strong></div>
<div><span>VERIFIED</span><strong><?=$stats['verified']?></strong></div>
</div>

<div class="admin-grid">
<section class="admin-panel"><div class="panel-head"><h2>Recent listings</h2><a href="listings.php">Manage all →</a></div>
<?php foreach($recentListings as $l): ?>
<div class="admin-row"><div><strong><?=htmlspecialchars($l['name'])?></strong><small><?=htmlspecialchars($l['category_name'] ?: 'Uncategorized')?> · <?=htmlspecialchars($l['location'] ?: 'No location')?></small></div><span class="status <?=htmlspecialchars($l['status'])?>"><?=htmlspecialchars($l['status'])?></span></div>
<?php endforeach; if(!$recentListings): ?><p class="muted">No listings yet.</p><?php endif; ?></section>

<section class="admin-panel"><div class="panel-head"><h2>Recent users</h2><a href="users.php">Manage all →</a></div>
<?php foreach($recentUsers as $u): ?>
<div class="admin-row"><div><strong><?=htmlspecialchars($u['full_name'])?></strong><small><?=htmlspecialchars($u['email'])?></small></div><span class="role-pill"><?=htmlspecialchars($u['role'])?></span></div>
<?php endforeach; ?></section>
</div>

<div class="admin-actions">
<a href="listings.php">📋 Listings & approvals</a><a href="users.php">👥 Users</a><a href="categories.php">🗂️ Categories</a>
</div>
<section class="admin-links"><a class="card" href="events.php"><h2>Events</h2><p>Approve, hide or delete events.</p></a><a class="card" href="opportunities.php"><h2>Opportunities</h2><p>Moderate jobs, scholarships and other opportunities.</p></a></section></main></body></html>
