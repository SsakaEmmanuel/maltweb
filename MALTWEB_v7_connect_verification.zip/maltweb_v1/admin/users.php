<?php
require_once __DIR__ . '/guard.php';
$pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST'){
    $id=(int)($_POST['id']??0); $action=$_POST['action']??'';
    if($action==='role'){ $role=$_POST['role']??'user'; if(in_array($role,['user','business','service_provider','admin'],true)) $pdo->prepare("UPDATE users SET role=? WHERE id=?")->execute([$role,$id]); }
    if($action==='delete' && $id!==$_SESSION['user_id']) $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
}
$users=$pdo->query("SELECT id,full_name,email,role,created_at FROM users ORDER BY id DESC")->fetchAll();
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Users — MALTWEB Admin</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><header class="admin-header"><a class="brand" href="../index.php"><span class="brand-mark">M</span><span>MALT<span>WEB</span></span></a><a href="index.php">← Admin dashboard</a></header>
<main class="admin-wrap"><span class="kicker">PEOPLE</span><h1>User management</h1><div class="admin-table"><?php foreach($users as $u): ?><div class="table-row"><div><strong><?=htmlspecialchars($u['full_name'])?></strong><small><?=htmlspecialchars($u['email'])?></small></div><div class="row-actions"><form method="post"><input type="hidden" name="id" value="<?=$u['id']?>"><select name="role"><?php foreach(['user','business','service_provider','admin'] as $role): ?><option <?=$u['role']===$role?'selected':''?>><?=$role?></option><?php endforeach; ?></select><button name="action" value="role">Save role</button></form><?php if($u['id']!==$_SESSION['user_id']): ?><form method="post" onsubmit="return confirm('Delete this account?')"><input type="hidden" name="id" value="<?=$u['id']?>"><button class="danger" name="action" value="delete">Delete</button></form><?php endif; ?></div></div><?php endforeach; ?></div></main></body></html>
