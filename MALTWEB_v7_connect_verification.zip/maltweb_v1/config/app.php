<?php
define('APP_NAME', 'MALTWEB');
define('APP_URL', '/maltweb');
define('DB_PATH', __DIR__ . '/../database/maltweb.sqlite');
session_start();
