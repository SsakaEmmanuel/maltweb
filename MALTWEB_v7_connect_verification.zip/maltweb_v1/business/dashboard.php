
<?php
session_start(); require_once __DIR__.'/../config/database.php';
if(!isset($_SESSION['user']) || !in_array($_SESSION['user']['role'],['business','service_provider'],true)){header('Location: ../auth/login.php');exit;}
$db=getDB();$uid=(int)$_SESSION['user']['id'];
$st=$db->prepare("SELECT l.*,c.name category_name FROM listings l LEFT JOIN categories c ON c.id=l.category_id WHERE l.owner_id=? ORDER BY l.id DESC");$st->execute([$uid]);$listings=$st->fetchAll(PDO::FETCH_ASSOC);
$st=$db->prepare("SELECT COUNT(*) FROM events WHERE owner_id=?");$st->execute([$uid]);$eventCount=(int)$st->fetchColumn();
$st=$db->prepare("SELECT COUNT(*) FROM opportunities WHERE owner_id=?");$st->execute([$uid]);$oppCount=(int)$st->fetchColumn();
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Creator Dashboard • MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><main class="container" style="padding:40px 20px"><a href="../index.php">← MALTWEB</a>
<div class="section-heading"><div><span class="eyebrow">CREATOR SPACE</span><h1><?=htmlspecialchars($_SESSION['user']['role']==='business'?'Business':'Service Provider')?> Dashboard</h1><p>Manage your public presence and community activity.</p></div><a class="btn" href="../listing/create.php">+ New profile</a></div>
<div class="stats-grid"><div class="stat-card"><strong><?=count($listings)?></strong><span>Profiles</span></div><div class="stat-card"><strong><?=$eventCount?></strong><span>Events</span></div><div class="stat-card"><strong><?=$oppCount?></strong><span>Opportunities</span></div></div>
<section class="card"><h2>Your profiles</h2><?php foreach($listings as $l):?><div class="dash-row"><div><strong><?=htmlspecialchars($l['name'])?></strong><small><?=htmlspecialchars($l['category_name']??'')?></small></div><span class="status-pill"><?=htmlspecialchars($l['status'])?></span><a href="../listing/view.php?slug=<?=urlencode($l['slug'])?>">View</a></div><?php endforeach;if(!$listings):?><p>No profile yet. Create one to appear in MALTWEB discovery.</p><?php endif;?></section>
<section class="dashboard-actions"><a class="btn" href="../event/create.php">+ Create Event</a><a class="btn secondary" href="../opportunity/create.php">+ Post Opportunity</a></section>
<section class="dashboard-actions"><a class="btn secondary" href="../messages/inbox.php">✉ Messages</a><a class="btn secondary" href="../notifications.php">🔔 Notifications</a></section></main></body></html>
