<?php
require_once __DIR__ . '/../config/database.php';
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        header('Location: ../dashboard.php'); exit;
    }
    $message = 'Invalid email or password.';
}
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login — MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><main class="auth-page"><a class="brand" href="../index.php"><span class="brand-mark">M</span><span>MALT<span>WEB</span></span></a><div class="auth-card"><span class="kicker">WELCOME BACK</span><h1>Login to MALTWEB</h1><?php if($message): ?><div class="alert"><?=$message?></div><?php endif; ?><form method="post"><label>Email<input type="email" name="email" required></label><label>Password<input type="password" name="password" required></label><button class="button dark-button" type="submit">Login</button></form><p>New here? <a href="register.php">Create an account</a></p></div></main></body></html>
