<?php
require_once __DIR__ . '/../config/database.php';
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'user';
    $allowed = ['user','business','service_provider'];
    if (!in_array($role, $allowed, true)) $role = 'user';
    if ($name && filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($password) >= 6) {
        try {
            $stmt = db()->prepare('INSERT INTO users(full_name,email,password_hash,role) VALUES(?,?,?,?)');
            $stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),$role]);
            header('Location: login.php'); exit;
        } catch (PDOException $e) { $message = 'That email is already registered.'; }
    } else $message = 'Please complete all fields. Password must be at least 6 characters.';
}
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Create account — MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><main class="auth-page"><a class="brand" href="../index.php"><span class="brand-mark">M</span><span>MALT<span>WEB</span></span></a><div class="auth-card"><span class="kicker">JOIN MALTWEB</span><h1>Create your account</h1><?php if($message): ?><div class="alert"><?=$message?></div><?php endif; ?><form method="post"><label>Full name<input name="full_name" required></label><label>Email<input type="email" name="email" required></label><label>Account type<select name="role"><option value="user">Ordinary user</option><option value="business">Business / Organization</option><option value="service_provider">Service provider</option></select></label><label>Password<input type="password" name="password" minlength="6" required></label><button class="button dark-button">Create account</button></form><p>Already registered? <a href="login.php">Login</a></p></div></main></body></html>
