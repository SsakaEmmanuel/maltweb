
<?php
session_start();
require_once __DIR__.'/../config/database.php';
if(!isset($_SESSION['user'])){header('Location: ../auth/login.php');exit;}
$db=getDB();$uid=(int)$_SESSION['user']['id'];
$st=$db->prepare("SELECT * FROM listings WHERE owner_id=? ORDER BY id DESC");$st->execute([$uid]);$listings=$st->fetchAll(PDO::FETCH_ASSOC);
$st=$db->prepare("SELECT f.*,l.name,l.slug FROM favourites f JOIN listings l ON l.id=f.listing_id WHERE f.user_id=? ORDER BY f.created_at DESC");$st->execute([$uid]);$favs=$st->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>User Dashboard • MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><main class="container" style="padding:40px 20px">
<a href="../index.php">← MALTWEB</a><div class="section-heading"><div><span class="eyebrow">MY SPACE</span><h1>Welcome, <?=htmlspecialchars($_SESSION['user']['full_name'])?></h1><p>Your MALTWEB activity in one place.</p></div><a class="btn" href="../listing/create.php">+ Create profile</a></div>
<div class="dashboard-grid"><section class="card"><h2>My profiles</h2><?php if(!$listings):?><p>You haven't created a profile yet.</p><?php else:foreach($listings as $l):?><div class="dash-row"><div><strong><?=htmlspecialchars($l['name'])?></strong><small><?=htmlspecialchars($l['listing_type'])?> · <?=htmlspecialchars($l['status'])?></small></div><a href="../listing/view.php?slug=<?=urlencode($l['slug'])?>">View</a></div><?php endforeach;endif;?></section>
<section class="card"><h2>Saved profiles</h2><?php if(!$favs):?><p>No favourites yet. Save useful profiles from their public pages.</p><?php else:foreach($favs as $f):?><div class="dash-row"><a href="../listing/view.php?slug=<?=urlencode($f['slug'])?>"><?=htmlspecialchars($f['name'])?></a><span>★</span></div><?php endforeach;endif;?></section></div>
<section class="dashboard-actions"><a class="btn secondary" href="../messages/inbox.php">✉ Messages</a><a class="btn secondary" href="../notifications.php">🔔 Notifications</a></section></main></body></html>
