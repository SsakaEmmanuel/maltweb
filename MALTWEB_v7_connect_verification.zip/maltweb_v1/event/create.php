
<?php
session_start();
require_once __DIR__ . '/../config/database.php';
if (!isset($_SESSION['user'])) { header('Location: ../auth/login.php'); exit; }

$db=getDB(); $error=''; $success='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $title=trim($_POST['title']??'');
    $description=trim($_POST['description']??'');
    $location=trim($_POST['location']??'');
    $date=trim($_POST['event_date']??'');
    $type=trim($_POST['event_type']??'Community Event');
    $phone=trim($_POST['contact_phone']??'');
    $email=trim($_POST['contact_email']??'');
    $website=trim($_POST['website']??'');
    if ($title==='' || $description==='' || $date==='') $error='Title, description and event date are required.';
    else {
        $stmt=$db->prepare("INSERT INTO events(owner_id,title,description,location,event_date,event_type,contact_phone,contact_email,website,status) VALUES(?,?,?,?,?,?,?,?,?,'pending')");
        $stmt->execute([$_SESSION['user']['id'],$title,$description,$location,$date,$type,$phone,$email,$website]);
        $success='Event submitted. It will appear publicly after admin approval.';
    }
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Create Event • MALTWEB</title><link rel="stylesheet" href="../assets/css/maltweb.css"></head>
<body><main class="container" style="padding:40px 20px"><div class="card form-card">
<a href="../dashboard.php">← Dashboard</a><h1>Create an event</h1>
<?php if($error):?><div class="notice error"><?=htmlspecialchars($error)?></div><?php endif;?>
<?php if($success):?><div class="notice success"><?=htmlspecialchars($success)?></div><?php endif;?>
<form method="post">
<label>Event title<input name="title" required></label>
<label>Event type<select name="event_type"><?php foreach(['Church','Community','Education','Business','Entertainment','Sports','Technology','Training','Other'] as $x):?><option><?=htmlspecialchars($x)?></option><?php endforeach;?></select></label>
<label>Description<textarea name="description" rows="6" required></textarea></label>
<label>Location / area<input name="location"></label>
<label>Date & time<input type="datetime-local" name="event_date" required></label>
<label>Contact phone<input name="contact_phone"></label>
<label>Contact email<input type="email" name="contact_email"></label>
<label>Website<input name="website" placeholder="https://..."></label>
<button class="btn" type="submit">Submit event</button>
</form></div></main></body></html>
